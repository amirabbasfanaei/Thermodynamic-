"""Industrial-style throttling calculator (pure fluids) using:
- Peng–Robinson EOS
- Ideal-gas Cp(T) polynomial
- Phase-aware handling for single- and two-phase states of pure components

Run:
    pip install -r requirements.txt
    streamlit run app.py
"""
from __future__ import annotations

import math
import streamlit as st

from thermo.fluids import GAS_CP, PR_DB, list_fluids
from thermo.throttle import solve_throttle

st.set_page_config(page_title="Throttling (Isenthalpic) Calculator", layout="wide")
st.title("Throttling (Isenthalpic) Calculator — Peng–Robinson (Pure Fluids)")

with st.expander("Model and assumptions", expanded=False):
    st.markdown(
        r"""
**Governing equation (steady throttling):**  \(h_1 = h_2\)

**Thermo model:** Peng–Robinson EOS for pure fluids + ideal-gas \(C_p(T)\) polynomial.  
**Two-phase detection (pure fluid):** saturation conditions are computed from \(\ln\phi^L=\ln\phi^V\), using:
- \(T_{sat}(P)\) when pressure is fixed
- \(P_{sat}(T)\) when temperature is fixed

If \(h\) lies between saturated liquid/vapor enthalpies at the saturation point, the state is reported as two-phase with:
\[
x = \frac{h - h_L}{h_V - h_L}
\]

**Units (internal):** K, Pa, J/mol.
"""
    )

fluid_name = st.sidebar.selectbox("Fluid", list_fluids(), index=0)
params = PR_DB[fluid_name]
cp = GAS_CP[fluid_name]
st.sidebar.markdown("---")
unknown = st.sidebar.selectbox("Unknown variable", ["T2", "P2", "T1", "P1"], index=0)

colA, colB = st.columns(2)

def bar_to_pa(p_bar: float) -> float:
    return p_bar * 1e5

def pa_to_bar(p_pa: float) -> float:
    return p_pa / 1e5

def fmt(x: float, nd: int = 6) -> str:
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return "—"
    return f"{x:.{nd}g}"

with colA:
    st.subheader("Inputs")
    T1 = st.number_input("T1 [K]", value=350.0, disabled=(unknown == "T1"))
    P1_bar = st.number_input("P1 [bar]", value=50.0, disabled=(unknown == "P1"))
    T2 = st.number_input("T2 [K]", value=300.0, disabled=(unknown == "T2"))
    P2_bar = st.number_input("P2 [bar]", value=10.0, disabled=(unknown == "P2"))

    known = {}
    if unknown != "T1":
        known["T1"] = float(T1)
    if unknown != "P1":
        known["P1"] = bar_to_pa(float(P1_bar))
    if unknown != "T2":
        known["T2"] = float(T2)
    if unknown != "P2":
        known["P2"] = bar_to_pa(float(P2_bar))

    run = st.button("Solve", type="primary")

with colB:
    st.subheader("Results")
    if run:
        try:
            res = solve_throttle(fluid_name, params, cp, known, unknown=unknown)  # type: ignore[arg-type]

            st.markdown("### State points")
            out = {
                "T1 [K]": res.T1,
                "P1 [bar]": pa_to_bar(res.P1),
                "T2 [K]": res.T2,
                "P2 [bar]": pa_to_bar(res.P2),
            }
            st.json({k: float(fmt(v, 10)) if fmt(v, 10) != "—" else None for k, v in out.items()})

            st.markdown("### Phases")
            st.write(f"Inlet phase: **{res.phase1}**   |   Outlet phase: **{res.phase2}**")
            if res.phase2 == "two-phase":
                st.write(f"Quality: **x = {res.quality:.6f}**")

            st.markdown("### Enthalpy (molar)")
            st.write(f"h1 = **{res.h1:.6g} J/mol**")
            st.write(f"h2 = **{res.h2:.6g} J/mol**")
            st.write(f"Residual check: **h2 - h1 = {res.residual_h:.3e} J/mol**")

            st.markdown("### EOS diagnostics")
            st.write(f"Z1 = {fmt(res.Z1, 8)}   |   Z2 = {fmt(res.Z2, 8)}")
            if math.isfinite(res.sat_residual_lnphi):
                st.write(f"Saturation residual (lnφL - lnφV): {res.sat_residual_lnphi:.3e}")

            st.success("Solved successfully.")
        except Exception as e:
            st.error(f"Solver failed: {e}")
            st.info("Tips: keep temperatures within Cp validity; saturation may fail very near critical conditions.")
