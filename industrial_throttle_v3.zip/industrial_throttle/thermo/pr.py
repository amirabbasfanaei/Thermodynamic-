"""Peng–Robinson EOS for pure fluids (property package core).

All enthalpies are returned in J/mol.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Literal, Tuple
import math

Phase = Literal["vapor", "liquid"]

R_UNIVERSAL = 8.31446261815324  # J/mol-K


@dataclass(frozen=True)
class PRFluid:
    Tc: float   # K
    Pc: float   # Pa
    omega: float
    R: float = R_UNIVERSAL

    @property
    def kappa(self) -> float:
        w = self.omega
        return 0.37464 + 1.54226*w - 0.26992*w*w

    def alpha(self, T: float) -> float:
        Tr = T / self.Tc
        return (1.0 + self.kappa * (1.0 - math.sqrt(Tr)))**2

    def dalpha_dT(self, T: float) -> float:
        Tr = T / self.Tc
        sqrtTr = math.sqrt(Tr)
        term = 1.0 + self.kappa * (1.0 - sqrtTr)
        dterm = -self.kappa * (1.0 / (2.0 * sqrtTr)) * (1.0 / self.Tc)
        return 2.0 * term * dterm

    def a(self, T: float) -> float:
        a0 = 0.45724 * self.R*self.R * self.Tc*self.Tc / self.Pc
        return a0 * self.alpha(T)

    def da_dT(self, T: float) -> float:
        a0 = 0.45724 * self.R*self.R * self.Tc*self.Tc / self.Pc
        return a0 * self.dalpha_dT(T)

    @property
    def b(self) -> float:
        return 0.07780 * self.R * self.Tc / self.Pc

    def AB(self, T: float, P: float) -> Tuple[float, float, float, float]:
        aT = self.a(T)
        b = self.b
        A = aT * P / (self.R*self.R*T*T)
        B = b * P / (self.R*T)
        return A, B, aT, b

    def cubic_Z_roots(self, T: float, P: float) -> List[float]:
        A, B, _, _ = self.AB(T, P)
        c2 = -(1.0 - B)
        c1 = (A - 3.0*B*B - 2.0*B)
        c0 = -(A*B - B*B - B**3)
        return _cubic_real_roots(1.0, c2, c1, c0)

    def ln_phi(self, T: float, P: float, Z: float) -> float:
        A, B, _, _ = self.AB(T, P)
        sqrt2 = math.sqrt(2.0)
        if Z <= B:
            raise ValueError("Invalid Z (Z <= B) causes log singularity.")
        term1 = Z - 1.0 - math.log(Z - B)
        term2 = A / (2.0*sqrt2*B)
        arg = (Z + (1.0 + sqrt2)*B) / (Z + (1.0 - sqrt2)*B)
        if arg <= 0.0:
            raise ValueError("Invalid log argument in ln_phi.")
        return term1 - term2 * math.log(arg)

    def stable_Z(self, T: float, P: float) -> Tuple[float, Phase]:
        roots = self.cubic_Z_roots(T, P)
        if not roots:
            raise ValueError("No real Z roots found.")
        if len(roots) == 1:
            return roots[0], "vapor"
        Zl = min(roots)
        Zv = max(roots)
        lnphil = self.ln_phi(T, P, Zl)
        lnphiv = self.ln_phi(T, P, Zv)
        return (Zl, "liquid") if lnphil <= lnphiv else (Zv, "vapor")

    def h_res(self, T: float, P: float, Z: float) -> float:
        A, B, aT, b = self.AB(T, P)
        daT = self.da_dT(T)
        sqrt2 = math.sqrt(2.0)
        arg = (Z + (1.0 + sqrt2)*B) / (Z + (1.0 - sqrt2)*B)
        if arg <= 0.0:
            raise ValueError("Invalid log argument in h_res.")
        return self.R*T*(Z - 1.0) + (T*daT - aT) / (2.0*sqrt2*b) * math.log(arg)

    def h_total(self, T: float, P: float, h_ig_rel: float, prefer: Phase | None = None) -> Tuple[float, Phase, float]:
        roots = self.cubic_Z_roots(T, P)
        if not roots:
            raise ValueError("No real Z roots found.")

        if len(roots) == 1:
            Z = roots[0]
            ph: Phase = "vapor"
        else:
            Zl = min(roots)
            Zv = max(roots)
            if prefer == "liquid":
                Z, ph = Zl, "liquid"
            elif prefer == "vapor":
                Z, ph = Zv, "vapor"
            else:
                Z, ph = self.stable_Z(T, P)

        return h_ig_rel + self.h_res(T, P, Z), ph, Z


def _cubic_real_roots(a: float, b: float, c: float, d: float) -> List[float]:
    """Return a sorted list of real roots of a x^3 + b x^2 + c x + d = 0."""
    if abs(a) < 1e-20:
        raise ValueError("Not a cubic (a≈0).")

    p = (3*a*c - b*b) / (3*a*a)
    q = (2*b*b*b - 9*a*b*c + 27*a*a*d) / (27*a*a*a)
    offset = -b / (3*a)

    disc = (q/2.0)**2 + (p/3.0)**3

    if disc > 0.0:
        sqrt_disc = math.sqrt(disc)
        u = _cuberoot(-q/2.0 + sqrt_disc)
        v = _cuberoot(-q/2.0 - sqrt_disc)
        y = u + v
        roots = [y + offset]
    elif abs(disc) <= 1e-14:
        u = _cuberoot(-q/2.0)
        y1 = 2*u
        y2 = -u
        roots = [y1 + offset, y2 + offset]
    else:
        r = math.sqrt(-(p**3)/27.0)
        phi = math.acos(-q/(2.0*r))
        m = 2.0 * math.sqrt(-p/3.0)
        y1 = m * math.cos(phi/3.0)
        y2 = m * math.cos((phi + 2.0*math.pi)/3.0)
        y3 = m * math.cos((phi + 4.0*math.pi)/3.0)
        roots = [y1 + offset, y2 + offset, y3 + offset]

    real_roots = sorted(set([round(float(x), 14) for x in roots if math.isfinite(x)]))
    return real_roots


def _cuberoot(x: float) -> float:
    return math.copysign(abs(x)**(1.0/3.0), x)
