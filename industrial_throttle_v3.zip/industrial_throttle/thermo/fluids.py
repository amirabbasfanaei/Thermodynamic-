"""Fluid database (pure components) limited to the fluids included in the original app.

Units:
- Tc [K]
- Pc [Pa]
- omega [-]
- Cp ideal-gas polynomial returns Cp [J/mol-K] (numerically equal to kJ/kmol-K)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple


@dataclass(frozen=True)
class CpPoly3:
    """
    Cp(T) = a + b T + c T^2 + d T^3  (J/mol-K)
    Validity range: Tmin..Tmax (K)

    Note: J/mol-K is numerically equal to kJ/kmol-K.
    """
    a: float
    b: float
    c: float
    d: float
    Tmin: float
    Tmax: float

    def cp(self, T: float) -> float:
        self._check_T(T)
        return self.a + self.b*T + self.c*T*T + self.d*T*T*T

    def h_ig_rel(self, T: float, Tref: float = 298.15) -> float:
        """Ideal-gas enthalpy relative to Tref: ∫ Cp dT  [J/mol]."""
        self._check_T(T)
        self._check_T(Tref)
        a, b, c, d = self.a, self.b, self.c, self.d
        return (
            a*(T - Tref)
            + (b/2.0)*(T*T - Tref*Tref)
            + (c/3.0)*(T**3 - Tref**3)
            + (d/4.0)*(T**4 - Tref**4)
        )

    def _check_T(self, T: float) -> None:
        if not (self.Tmin <= T <= self.Tmax):
            raise ValueError(f"T={T:.3f} K outside Cp validity range [{self.Tmin}, {self.Tmax}] K")


@dataclass(frozen=True)
class PRParams:
    Tc: float   # K
    Pc: float   # Pa
    omega: float


GAS_CP: Dict[str, CpPoly3] = {
    "Methane (CH4)":  CpPoly3(a=19.89, b=5.0240e-2, c=1.269e-5,  d=-11.01e-9, Tmin=273.0, Tmax=1500.0),
    "Nitrogen (N2)":  CpPoly3(a=28.90, b=-0.1571e-2, c=0.8081e-5, d=-2.873e-9, Tmin=273.0, Tmax=1800.0),
    "Oxygen (O2)":    CpPoly3(a=25.48, b=1.5200e-2,  c=-0.7155e-5, d=1.312e-9,  Tmin=273.0, Tmax=1800.0),
    "Air":            CpPoly3(a=28.11, b=0.1967e-2,  c=0.4802e-5, d=-1.966e-9, Tmin=273.0, Tmax=1800.0),
    "Carbon Dioxide (CO2)": CpPoly3(a=22.26, b=5.9810e-2, c=-3.501e-5, d=7.469e-9, Tmin=273.0, Tmax=1800.0),
    "Carbon Monoxide (CO)": CpPoly3(a=28.16, b=0.1675e-2, c=0.5372e-5, d=-2.222e-9, Tmin=273.0, Tmax=1800.0),
    "Hydrogen (H2)":  CpPoly3(a=29.11, b=-0.1916e-2, c=0.4003e-5, d=-8.704e-9, Tmin=273.0, Tmax=1800.0),
}

PR_DB: Dict[str, PRParams] = {
    "Methane (CH4)": PRParams(Tc=190.564, Pc=4.5992e6, omega=0.011),
    "Nitrogen (N2)": PRParams(Tc=126.192, Pc=3.3958e6, omega=0.0372),
    "Oxygen (O2)":   PRParams(Tc=154.581, Pc=5.0430e6, omega=0.0222),
    "Carbon Dioxide (CO2)": PRParams(Tc=304.1282, Pc=7.3773e6, omega=0.22394),
    "Carbon Monoxide (CO)": PRParams(Tc=132.86, Pc=3.499e6, omega=0.049),
    "Hydrogen (H2)": PRParams(Tc=33.145, Pc=1.296e6, omega=-0.22),
    "Air": PRParams(Tc=132.5, Pc=3.77e6, omega=0.04),
}

def list_fluids() -> Tuple[str, ...]:
    return tuple(PR_DB.keys())
