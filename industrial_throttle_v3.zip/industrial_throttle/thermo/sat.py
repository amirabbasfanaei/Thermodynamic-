"""Saturation solvers for pure fluids using equality of fugacities:
    f^L = f^V  <=>  ln(phi_L) = ln(phi_V)

For pseudo-pure "Air" in this demo, saturation is disabled.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
import math

from .pr import PRFluid
from .utils import bisect


@dataclass(frozen=True)
class SatResult:
    value: float
    iters: int
    residual: float


def Psat_from_T(fluid_name: str, eos: PRFluid, T: float, P_lo: float, P_hi: float) -> Optional[SatResult]:
    if fluid_name == "Air":
        return None

    def g(P: float) -> float:
        roots = eos.cubic_Z_roots(T, P)
        if len(roots) < 2:
            return float("nan")
        Zl, Zv = min(roots), max(roots)
        return eos.ln_phi(T, P, Zl) - eos.ln_phi(T, P, Zv)

    # scan in log P to find a bracket
    nscan = 70
    loglo = math.log(P_lo)
    loghi = math.log(P_hi)
    lastP = None
    lastg = None
    bracket = None
    for i in range(nscan):
        P = math.exp(loglo + (loghi - loglo) * i / (nscan - 1))
        try:
            val = g(P)
        except Exception:
            val = float("nan")
        if math.isfinite(val):
            if lastP is not None and lastg is not None and val * lastg <= 0.0:
                bracket = (lastP, P)
                break
            lastP, lastg = P, val

    if bracket is None:
        return None

    rr = bisect(g, bracket[0], bracket[1], tol=1e-10, max_iter=300)
    return SatResult(rr.x, rr.iters, rr.f)


def Tsat_from_P(fluid_name: str, eos: PRFluid, P: float, T_lo: float, T_hi: float) -> Optional[SatResult]:
    if fluid_name == "Air":
        return None

    def g(T: float) -> float:
        roots = eos.cubic_Z_roots(T, P)
        if len(roots) < 2:
            return float("nan")
        Zl, Zv = min(roots), max(roots)
        return eos.ln_phi(T, P, Zl) - eos.ln_phi(T, P, Zv)

    nscan = 90
    lastT = None
    lastg = None
    bracket = None
    for i in range(nscan):
        T = T_lo + (T_hi - T_lo) * i / (nscan - 1)
        try:
            val = g(T)
        except Exception:
            val = float("nan")
        if math.isfinite(val):
            if lastT is not None and lastg is not None and val * lastg <= 0.0:
                bracket = (lastT, T)
                break
            lastT, lastg = T, val

    if bracket is None:
        return None

    rr = bisect(g, bracket[0], bracket[1], tol=1e-10, max_iter=300)
    return SatResult(rr.x, rr.iters, rr.f)
