"""Numerical utilities (safe bracketing + bisection)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Tuple
import math


@dataclass(frozen=True)
class RootResult:
    x: float
    f: float
    iters: int
    bracket: Tuple[float, float]


def bracket_root(
    f: Callable[[float], float],
    x0: float,
    step: float,
    x_min: float,
    x_max: float,
    max_expand: int = 60,
) -> Optional[Tuple[float, float]]:
    """Expand a bracket around x0 until a sign change is found."""
    a = max(x_min, x0 - step)
    b = min(x_max, x0 + step)

    def safe_eval(x: float) -> Optional[float]:
        try:
            y = f(x)
            if not math.isfinite(y):
                return None
            return y
        except Exception:
            return None

    fa = safe_eval(a)
    fb = safe_eval(b)

    k = 0
    while k < max_expand:
        if fa is not None and fb is not None and fa * fb <= 0.0:
            return (a, b)

        step *= 1.5
        a = max(x_min, x0 - step)
        b = min(x_max, x0 + step)
        fa = safe_eval(a)
        fb = safe_eval(b)

        if a == x_min and b == x_max:
            break
        k += 1

    return None


def bisect(
    f: Callable[[float], float],
    a: float,
    b: float,
    tol: float = 1e-8,
    max_iter: int = 250,
) -> RootResult:
    """Robust bisection on [a,b] with f(a)*f(b) <= 0."""
    fa = f(a)
    fb = f(b)
    if fa == 0.0:
        return RootResult(a, fa, 0, (a, b))
    if fb == 0.0:
        return RootResult(b, fb, 0, (a, b))
    if fa * fb > 0.0:
        raise ValueError("Bisection requires a sign change on [a,b].")

    lo, hi = a, b
    flo, fhi = fa, fb
    it = 0
    while it < max_iter:
        mid = 0.5 * (lo + hi)
        fmid = f(mid)
        if abs(fmid) < tol or abs(hi - lo) < tol:
            return RootResult(mid, fmid, it + 1, (a, b))

        if flo * fmid <= 0.0:
            hi, fhi = mid, fmid
        else:
            lo, flo = mid, fmid
        it += 1

    mid = 0.5 * (lo + hi)
    return RootResult(mid, f(mid), it, (a, b))
