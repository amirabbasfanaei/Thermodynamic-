"""Throttling (isenthalpic) solver for a PURE fluid with PR EOS + ideal-gas Cp(T).

Governing equation (steady throttling, adiabatic, no shaft work, negligible KE/PE):
    h1 = h2

Two-phase handling for a pure component:
- At fixed pressure P: find Tsat(P) from ln(phi_L)=ln(phi_V).
  If h is between saturated liquid/vapor enthalpies, the state is two-phase and:
      x = (h - hL)/(hV - hL),  T = Tsat(P)
- At fixed temperature T: find Psat(T) from ln(phi_L)=ln(phi_V).
  If h is between saturated enthalpies at (T, Psat), the state is two-phase and:
      x = (h - hL)/(hV - hL),  P = Psat(T)

All molar enthalpies returned in J/mol.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Tuple
import math

from .fluids import CpPoly3, PRParams
from .pr import PRFluid, Phase
from .sat import Tsat_from_P, Psat_from_T
from .utils import bracket_root, bisect

UnknownKey = Literal["T1", "P1", "T2", "P2"]

# Tolerances for identifying saturation consistency
SAT_TOL_T_K = 1e-3
SAT_TOL_P_REL = 1e-6


@dataclass(frozen=True)
class ThrottleResult:
    T1: float
    P1: float
    T2: float
    P2: float
    h1: float
    h2: float
    phase1: str
    phase2: str  # "liquid"/"vapor"/"two-phase"
    Z1: float
    Z2: float
    quality: float  # x if two-phase else NaN
    residual_h: float  # h2 - h1
    sat_residual_lnphi: float  # if saturation computed, else NaN


def _h_total_single(eos: PRFluid, cp: CpPoly3, T: float, P: float, prefer: Phase | None = None) -> Tuple[float, str, float]:
    h_ig = cp.h_ig_rel(T)
    h, ph, Z = eos.h_total(T, P, h_ig_rel=h_ig, prefer=prefer)
    return h, ph, Z


def _sat_bounds_T(cp: CpPoly3, eos: PRFluid) -> Tuple[float, float]:
    # Keep within Cp range and below critical temperature
    lo = max(cp.Tmin, 0.35 * eos.Tc)
    hi = min(cp.Tmax, 0.999 * eos.Tc)
    return lo, hi


def _try_two_phase_from_hP(
    fluid_name: str,
    eos: PRFluid,
    cp: CpPoly3,
    h_target: float,
    P: float,
) -> Tuple[bool, float, float, float]:
    """Try to classify as two-phase given (h, P). Returns (is_two_phase, T_sat, x, lnphi_residual)."""
    if fluid_name == "Air":
        return False, float("nan"), float("nan"), float("nan")
    if P >= eos.Pc * 0.999:
        return False, float("nan"), float("nan"), float("nan")

    T_lo, T_hi = _sat_bounds_T(cp, eos)
    Ts = Tsat_from_P(fluid_name, eos, P, T_lo=T_lo, T_hi=T_hi)
    if Ts is None:
        return False, float("nan"), float("nan"), float("nan")

    T_sat = Ts.value
    hL, _, _ = _h_total_single(eos, cp, T_sat, P, prefer="liquid")
    hV, _, _ = _h_total_single(eos, cp, T_sat, P, prefer="vapor")
    if hL <= h_target <= hV and abs(hV - hL) > 1e-12:
        x = (h_target - hL) / (hV - hL)
        return True, T_sat, x, Ts.residual

    return False, float("nan"), float("nan"), float("nan")


def _try_two_phase_from_hT(
    fluid_name: str,
    eos: PRFluid,
    cp: CpPoly3,
    h_target: float,
    T: float,
) -> Tuple[bool, float, float, float]:
    """Try to classify as two-phase given (h, T). Returns (is_two_phase, P_sat, x, lnphi_residual)."""
    if fluid_name == "Air":
        return False, float("nan"), float("nan"), float("nan")
    if T >= eos.Tc * 0.999:
        return False, float("nan"), float("nan"), float("nan")

    P_hi = min(0.999 * eos.Pc, 1e8)
    Ps = Psat_from_T(fluid_name, eos, T, P_lo=1e3, P_hi=P_hi)
    if Ps is None:
        return False, float("nan"), float("nan"), float("nan")

    P_sat = Ps.value
    hL, _, _ = _h_total_single(eos, cp, T, P_sat, prefer="liquid")
    hV, _, _ = _h_total_single(eos, cp, T, P_sat, prefer="vapor")
    if hL <= h_target <= hV and abs(hV - hL) > 1e-12:
        x = (h_target - hL) / (hV - hL)
        return True, P_sat, x, Ps.residual

    return False, float("nan"), float("nan"), float("nan")


def _solve_T_for_h(
    eos: PRFluid,
    cp: CpPoly3,
    h_target: float,
    P: float,
) -> Tuple[float, str, float, float]:
    """Solve h(T,P)=h_target for T (single-phase). Returns (T, phase, Z, h)."""
    Tmin, Tmax = cp.Tmin, cp.Tmax

    def F(T: float) -> float:
        h, _, _ = _h_total_single(eos, cp, T, P, prefer=None)
        return h - h_target

    T0 = min(max(0.7 * eos.Tc, Tmin), Tmax)
    br = bracket_root(F, x0=T0, step=10.0, x_min=Tmin, x_max=Tmax)
    if br is None:
        # scan fallback
        n = 160
        lastT = None
        lastF = None
        for i in range(n):
            T = Tmin + (Tmax - Tmin) * i / (n - 1)
            try:
                val = F(T)
            except Exception:
                continue
            if math.isfinite(val):
                if lastT is not None and lastF is not None and val * lastF <= 0.0:
                    br = (lastT, T)
                    break
                lastT, lastF = T, val
        if br is None:
            raise ValueError("Could not bracket temperature for h(T,P)=h_target.")

    rr = bisect(F, br[0], br[1], tol=1e-8, max_iter=300)
    T_sol = rr.x
    h_sol, ph, Z = _h_total_single(eos, cp, T_sol, P, prefer=None)
    return T_sol, ph, Z, h_sol


def _solve_P_for_h(
    eos: PRFluid,
    cp: CpPoly3,
    h_target: float,
    T: float,
) -> Tuple[float, str, float, float]:
    """Solve h(T,P)=h_target for P (single-phase). Returns (P, phase, Z, h)."""
    Pmin = 1e3
    Pmax = max(5.0 * eos.Pc, 1e8)

    def F(P: float) -> float:
        h, _, _ = _h_total_single(eos, cp, T, P, prefer=None)
        return h - h_target

    P0 = min(max(eos.Pc * 0.2, Pmin), Pmax)
    br = bracket_root(F, x0=P0, step=1e4, x_min=Pmin, x_max=Pmax)
    if br is None:
        raise ValueError("Could not bracket pressure for h(T,P)=h_target.")

    rr = bisect(F, br[0], br[1], tol=1e-6, max_iter=300)
    P_sol = rr.x
    h_sol, ph, Z = _h_total_single(eos, cp, T, P_sol, prefer=None)
    return P_sol, ph, Z, h_sol


def solve_throttle(
    fluid_name: str,
    params: PRParams,
    cp: CpPoly3,
    known: dict,
    unknown: UnknownKey,
) -> ThrottleResult:
    """Solve throttling problem. known must supply 3 of {T1,P1,T2,P2} (K, Pa)."""
    eos = PRFluid(Tc=params.Tc, Pc=params.Pc, omega=params.omega)

    # Inlet enthalpy (when T1,P1 are known)
    if unknown not in ("T1", "P1"):
        T1 = float(known["T1"])
        P1 = float(known["P1"])
        h1, ph1, Z1 = _h_total_single(eos, cp, T1, P1, prefer=None)
    else:
        T1 = float("nan")
        P1 = float("nan")
        h1 = float("nan")
        ph1 = "unknown"
        Z1 = float("nan")

    # ---------- Unknown T2 ----------
    if unknown == "T2":
        P2 = float(known["P2"])
        # First: try two-phase at (h1, P2)
        is2p, T_sat, x, satres = _try_two_phase_from_hP(fluid_name, eos, cp, h1, P2)
        if is2p:
            return ThrottleResult(
                T1=T1, P1=P1, T2=T_sat, P2=P2,
                h1=h1, h2=h1,
                phase1=ph1, phase2="two-phase",
                Z1=Z1, Z2=float("nan"),
                quality=x,
                residual_h=0.0,
                sat_residual_lnphi=satres,
            )

        # Otherwise single-phase: solve T2 from h(T2,P2)=h1
        T2, ph2, Z2, h2 = _solve_T_for_h(eos, cp, h1, P2)
        return ThrottleResult(
            T1=T1, P1=P1, T2=T2, P2=P2,
            h1=h1, h2=h2,
            phase1=ph1, phase2=ph2,
            Z1=Z1, Z2=Z2,
            quality=float("nan"),
            residual_h=h2 - h1,
            sat_residual_lnphi=float("nan"),
        )

    # ---------- Unknown P2 ----------
    if unknown == "P2":
        T2 = float(known["T2"])

        # First: two-phase must satisfy P2 = Psat(T2)
        is2p, P_sat, x, satres = _try_two_phase_from_hT(fluid_name, eos, cp, h1, T2)
        if is2p:
            return ThrottleResult(
                T1=T1, P1=P1, T2=T2, P2=P_sat,
                h1=h1, h2=h1,
                phase1=ph1, phase2="two-phase",
                Z1=Z1, Z2=float("nan"),
                quality=x,
                residual_h=0.0,
                sat_residual_lnphi=satres,
            )

        # Otherwise single-phase: solve P2 from h(T2,P2)=h1
        P2, ph2, Z2, h2 = _solve_P_for_h(eos, cp, h1, T2)

        # Post-check: if solution is effectively on saturation line and h1 is inside (hL,hV), label two-phase
        if fluid_name != "Air" and P2 < eos.Pc and T2 < eos.Tc * 0.999:
            T_lo, T_hi = _sat_bounds_T(cp, eos)
            Ts = Tsat_from_P(fluid_name, eos, P2, T_lo=T_lo, T_hi=T_hi)
            if Ts is not None and abs(T2 - Ts.value) < SAT_TOL_T_K:
                # additionally check Psat(T2) consistency
                Ps = Psat_from_T(fluid_name, eos, T2, P_lo=1e3, P_hi=min(0.999*eos.Pc, 1e8))
                if Ps is not None and abs(P2 - Ps.value) / P2 < SAT_TOL_P_REL:
                    hL, _, _ = _h_total_single(eos, cp, Ts.value, P2, prefer="liquid")
                    hV, _, _ = _h_total_single(eos, cp, Ts.value, P2, prefer="vapor")
                    if hL <= h1 <= hV and abs(hV - hL) > 1e-12:
                        x = (h1 - hL) / (hV - hL)
                        return ThrottleResult(
                            T1=T1, P1=P1, T2=T2, P2=P2,
                            h1=h1, h2=h1,
                            phase1=ph1, phase2="two-phase",
                            Z1=Z1, Z2=float("nan"),
                            quality=x,
                            residual_h=0.0,
                            sat_residual_lnphi=Ts.residual,
                        )

        return ThrottleResult(
            T1=T1, P1=P1, T2=T2, P2=P2,
            h1=h1, h2=h2,
            phase1=ph1, phase2=ph2,
            Z1=Z1, Z2=Z2,
            quality=float("nan"),
            residual_h=h2 - h1,
            sat_residual_lnphi=float("nan"),
        )

    # For remaining cases, outlet state is fully specified (T2,P2)
    T2 = float(known["T2"])
    P2 = float(known["P2"])
    h2, ph2, Z2 = _h_total_single(eos, cp, T2, P2, prefer=None)

    # ---------- Unknown T1 ----------
    if unknown == "T1":
        P1 = float(known["P1"])

        # Solve inlet temperature from h(T1,P1)=h2
        T1_sol, ph1_sol, Z1_sol, h1_sol = _solve_T_for_h(eos, cp, h2, P1)

        # Optional labeling: if outlet is exactly on saturation line and h2 is inside (hL,hV), compute quality
        quality = float("nan")
        satres = float("nan")
        if fluid_name != "Air" and P2 < eos.Pc and T2 < eos.Tc * 0.999:
            T_lo, T_hi = _sat_bounds_T(cp, eos)
            Ts = Tsat_from_P(fluid_name, eos, P2, T_lo=T_lo, T_hi=T_hi)
            if Ts is not None and abs(T2 - Ts.value) < SAT_TOL_T_K:
                hL, _, _ = _h_total_single(eos, cp, Ts.value, P2, prefer="liquid")
                hV, _, _ = _h_total_single(eos, cp, Ts.value, P2, prefer="vapor")
                if hL <= h2 <= hV and abs(hV - hL) > 1e-12:
                    quality = (h2 - hL) / (hV - hL)
                    satres = Ts.residual
                    ph2_out = "two-phase"
                else:
                    ph2_out = ph2
            else:
                ph2_out = ph2
        else:
            ph2_out = ph2

        return ThrottleResult(
            T1=T1_sol, P1=P1, T2=T2, P2=P2,
            h1=h1_sol, h2=h2,
            phase1=ph1_sol, phase2=ph2_out,
            Z1=Z1_sol, Z2=Z2,
            quality=quality,
            residual_h=h2 - h1_sol,
            sat_residual_lnphi=satres,
        )

    # ---------- Unknown P1 ----------
    if unknown == "P1":
        T1_in = float(known["T1"])

        # Solve inlet pressure from h(T1,P1)=h2
        P1_sol, ph1_sol, Z1_sol, h1_sol = _solve_P_for_h(eos, cp, h2, T1_in)

        quality = float("nan")
        satres = float("nan")
        if fluid_name != "Air" and P2 < eos.Pc and T2 < eos.Tc * 0.999:
            T_lo, T_hi = _sat_bounds_T(cp, eos)
            Ts = Tsat_from_P(fluid_name, eos, P2, T_lo=T_lo, T_hi=T_hi)
            if Ts is not None and abs(T2 - Ts.value) < SAT_TOL_T_K:
                hL, _, _ = _h_total_single(eos, cp, Ts.value, P2, prefer="liquid")
                hV, _, _ = _h_total_single(eos, cp, Ts.value, P2, prefer="vapor")
                if hL <= h2 <= hV and abs(hV - hL) > 1e-12:
                    quality = (h2 - hL) / (hV - hL)
                    satres = Ts.residual
                    ph2_out = "two-phase"
                else:
                    ph2_out = ph2
            else:
                ph2_out = ph2
        else:
            ph2_out = ph2

        return ThrottleResult(
            T1=T1_in, P1=P1_sol, T2=T2, P2=P2,
            h1=h1_sol, h2=h2,
            phase1=ph1_sol, phase2=ph2_out,
            Z1=Z1_sol, Z2=Z2,
            quality=quality,
            residual_h=h2 - h1_sol,
            sat_residual_lnphi=satres,
        )

    raise ValueError(f"Unknown key not supported: {unknown}")
